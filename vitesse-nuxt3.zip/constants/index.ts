export const appName = 'Vitesse for Nuxt 3'
export const appDescription = 'Vitesse for Nuxt 3'
